package br.edu.utfpr;

import java.util.Scanner;

public class Ex1 {
	//Nomes: PropriedadeRural, BagsOfCoffee
	//Verbos: Register
	//Adjetivos: Weight
	public static void main(String[] args) {
		Float weight = (float)0;
		Scanner reader = new Scanner(System.in);
		do {
			System.out.print("Digite o peso da saca de café: ");
			weight = reader.nextFloat();
			if(weight == -1) {
				break;
			}
			Coffee coffee = new Coffee(weight);			
			System.out.print(coffee + "\n");
		}while(weight != -1);
		System.out.println("Programa encerrado.");
		reader.close();
	}
}
