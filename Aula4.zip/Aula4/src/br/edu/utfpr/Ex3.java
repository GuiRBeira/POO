package br.edu.utfpr;

import java.util.Scanner;

public class Ex3 {

	public static void main(String[] args) {
		Scanner reader = new Scanner(System.in);
		Adder adder = new Adder(reader.nextInt());
		System.out.println(adder);
		reader.close();
	}
}
