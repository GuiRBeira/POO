package br.edu.utfpr;

import java.util.Scanner;

public class Palindromo {
	public static void main(String[] args) {
		Scanner reader = new Scanner(System.in);
		System.out.print("Insira a palavra: ");
		String word = new String(reader.next());
		boolean match = true;
		Integer start = 0;
		Integer end = word.length()-1;
		while(start <= end && match) {
			if(word.charAt(start) == word.charAt(end)) {
				start++;
				end--;
				match = true;
			} else {
				match = false;
			}
		}
		String result = "Não é palíndromo.";
		if(match) {
			result = "É palíndromo.";
		}
		System.out.println(result);
		reader.close();
	}
}
