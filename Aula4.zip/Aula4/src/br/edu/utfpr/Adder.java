package br.edu.utfpr;

public class Adder {
	Integer limit;
	public Adder(Integer limit) {
		this.limit = limit;
	}
	public String toString() {
		int aux = 0;
		for(int i = 0; i <= limit; i++) {
			aux += i;
		}
		return "Resultado: " + aux;
	}
}
