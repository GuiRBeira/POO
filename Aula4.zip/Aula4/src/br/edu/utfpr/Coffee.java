package br.edu.utfpr;

public class Coffee {
	private Float weight;
	private Float price;
	public Coffee(Float weight) {
		this.weight = weight;
		this.price = register();
	}
	private Float register() {
		Float aux = (float)0;
		if(weight < 30) {
			aux = (float)50.0; 
		} else if(weight > 31 && weight <= 60 ) {
			aux = (float)100.0;
		} else if(weight > 60) {
			aux = (float)200.0;
		}
		return aux;
	}
	public String toString() {
		return "Saca de Café:\n" + 
				"Peso: " + this.weight + "\n" +
				"Valor: " + this.price + "\n";
	}
}
